package restAssuredTests;

/*
  given()
       set cookies, add auth, add param, set headers info etc....
  when()
       get, post,put,delete...
  then()
       validate status code, extract response, extract headers cookies & response body....      
 */

public class Demo1_Get_Request {

	
}
